# empty region detector > 2025-04-21 9:35pm
https://universe.roboflow.com/empty-region-detection/empty-region-detector

Provided by a Roboflow user
License: CC BY 4.0

